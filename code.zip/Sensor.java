public abstract class Sensor {
    protected String location;
    public Sensor(String location) { this.location = location; }
    public abstract void detect();
    public String getLocation()    { return location; }
}

class MotionSensor extends Sensor {
    public MotionSensor(String location) { super(location); }
    @Override public void detect() {
        System.out.println("Motion detected at " + location);
    }
}

class DoorSensor extends Sensor {
    public DoorSensor(String location) { super(location); }
    @Override public void detect() {
        System.out.println("Door opened at " + location);
    }
}

class ThermostatSensor extends Sensor {
    public ThermostatSensor(String location) { super(location); }
    @Override public void detect() {
        System.out.println("Temperature threshold exceeded at " + location);
    }
}

// -- Naive client code (to be replaced) ------------------------------------
// Sensor s;
// if      (type.equals("MOTION")) s = new MotionSensor(loc);
// else if (type.equals("DOOR"))   s = new DoorSensor(loc);
// else if (type.equals("THERM"))  s = new ThermostatSensor(loc);
// else throw new IllegalArgumentException("Unknown sensor: " + type);
