public class SmartDevice {
    private final String  deviceId;           // required
    private final String  type;               // "LOCK" | "CAMERA" | "THERMOSTAT"
    private final String  location;           // required
    private final int     firmwareVersion;    // optional, default 1
    private final boolean isEncrypted;        // optional, default false
    private final int     pollingIntervalMs;  // optional, default 5000

    // Naive telescoping constructors
    public SmartDevice(String id, String type, String location) {
        this(id, type, location, 1, false, 5000);
    }
    public SmartDevice(String id, String type, String location, int fw) {
        this(id, type, location, fw, false, 5000);
    }
    public SmartDevice(String id, String type, String location,
                       int fw, boolean enc, int poll) {
        this.deviceId          = id;
        this.type              = type;
        this.location          = location;
        this.firmwareVersion   = fw;
        this.isEncrypted       = enc;
        this.pollingIntervalMs = poll;
    }
    @Override public String toString() {
        return String.format("[%s] %s @ %s | fw=%d enc=%b poll=%dms",
            deviceId, type, location, firmwareVersion, isEncrypted, pollingIntervalMs);
    }
}
